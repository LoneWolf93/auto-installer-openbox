#!/bin/bash


GREEN='\033[0;32m';
NOCOLOR='\033[0m';
BLINK='\e[5m';

function updateSys {
echo -e ${BLINK}Updating System${NOCOLOR}
sudo apt-get update
printf "${GREEN}Update Done, OK!${NOCOLOR}\n"
sleep 3
}


function upgradeSys {
echo -e ${BLINK}Upgrading System${NOCOLOR}
sudo apt-get upgrade
printf "${GREEN}Upgrade Done, OK!${NOCOLOR}\n"
sleep 3
}


function installXinit {
echo -e ${BLINK}Installing Xinit${NOCOLOR}
sudo apt-get --yes install xinit
sleep 3
printf "${GREEN}Xinit Installed!${NOCOLOR}\n"
}


function installSlimManager {
echo -e ${BLINK}Installing a Window Manager for Login in${NOCOLOR}
sudo apt-get --yes install slim
sleep 3
echo Enabling slim service
sudo systemctl enable slim.service
sleep 3
printf "${GREEN}Slim service enabled!${NOCOLOR}\n"
printf "${GREEN}Slim Manager Installed!${NOCOLOR}\n"
}


function installOpenbox {
echo -e ${BLINK}Installing a WM OpenBox${NOCOLOR}
sudo apt-get --yes install openbox
sleep 3
sudo apt-get --yes install obmenu obconf
sleep 3
printf "${GREEN}OpenBox Installed!${NOCOLOR}\n"
}


function installMenuBar {
echo -e ${BLINK}Installing a menu bar Tint2${NOCOLOR}
sudo apt-get --yes install tint2
sleep 3
printf "${GREEN}Tint2 Insalled${NOCOLOR}\n"
}


function installLockScreen {
echo -e ${BLINK}Installing a Lock ScreenSaver${NOCOLOR}
sudo apt-get --yes install xscreensaver
sleep 3
printf "${GREEN}xscreensaver Installed${NOCOLOR}\n"
}


function installNitrogen {
echo -e ${BLINK}Installing Nitrogen${NOCOLOR}
sudo apt-get --yes install nitrogen
sleep 3
printf "${GREEN}Nitrogen Installed${NOCOLOR}\n"
}


function installThunar {
echo -e ${BLINK}Installing Thunar File System${NOCOLOR}
sudo apt-get --yes install thunar
sleep 3
printf "${GREEN}Thunar Installed${NOCOLOR}\n"
}


function installGnomeIcons {
echo -e ${BLINK}Installing Gnome Icons${NOCOLOR}
sudo apt-get --yes install gnome-icon-theme-full
sleep 3
printf "${GREEN}Gnome Icons Installed${NOCOLOR}\n"
}


function installScreenFetch {
echo -e ${BLINK}Installing System Info${NOCOLOR}
sudo apt-get --yes install screenfetch
sleep 3
printf "${GREEN}screenfetch Installed${NOCOLOR}\n"
}



function installFirefox {
echo -e ${BLINK}Installing Firefox${NOCOLOR}
sudo apt-get --yes install firefox
sleep 3
printf "${GREEN}Firefox Installed${NOCOLOR}\n"
}


function installNetworkManager {
echo -e ${BLINK}Installing Network Manager WICD${NOCOLOR}
sudo apt-get --yes install wicd
sleep 3
printf "${GREEN}WICD Installed${NOCOLOR}\n"
}


function installVolumePanel {
echo -e ${BLINK}Installing a Volume Panel Control${NOCOLOR}
sudo apt-get --yes install gnome-alsamixer
sleep 3
printf "${GREEN}Alsamixer Installed${NOCOLOR}\n"
}


function installPulseAudio {
echo -e ${BLINK}Installing PulseAudio${NOCOLOR}
sudo apt-get --yes install pulseaudio
sleep 3
printf "${GREEN}PulseAudio Installed${NOCOLOR}\n"
}


function installCompressor {
echo -e ${BLINK}Installing xarchiver${NOCOLOR}
sudo apt-get --yes install xarchiver
sleep 3
printf "${GREEN}xarchiver Installed${NOCOLOR}\n"
}


function installGnomeEditor {
echo -e ${BLINK}Installing GEDIT${NOCOLOR}
sudo apt-get --yes install gedit
sleep 3
printf "${GREEN}GEDIT Installed${NOCOLOR}\n"
}


#<-------------------------------------------------------------------------->



function createDirOpenbox {
echo -e ${BLINK}Making dir named openbox${NOCOLOR}
mkdir ~/.config/openbox
sleep 3
printf "${GREEN}Directory created correctly!${NOCOLOR}\n"
}

function copyContent {
echo -e ${BLINK}Making a copy about autostart OpenBox${NOCOLOR}
mv -v content/autostart.sh ~/.config/openbox/
sleep 3
printf "${GREEN}Moved${NOCOLOR}\n"
}




#<--------------------------------MAIN--------------------------------------->


updateSys
upgradeSys
installXinit
installSlimManager
installOpenbox
installMenuBar
installLockScreen
installNitrogen
installThunar
installGnomeIcons
installScreenFetch
installFirefox
installNetworkManager
installVolumePanel
installPulseAudio
installCompressor
installGnomeEditor
createDirOpenbox
copyContent



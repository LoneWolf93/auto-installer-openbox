tint2 &

nitrogen --restore &

xrandr --output Virtual1 --mode 1280x768 &

xscreensaver -no-splash &


#Comentarios

# Con xscreensaver-command -lock --> bloqueas la sesion del usuario

#sudo apt-get install alsamixer --> para controlar el sonido
